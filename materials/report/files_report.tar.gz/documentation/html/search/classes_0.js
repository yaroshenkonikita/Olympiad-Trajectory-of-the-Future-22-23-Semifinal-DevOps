var searchData=
[
  ['chess_24',['Chess',['../classChess.html',1,'']]]
];
