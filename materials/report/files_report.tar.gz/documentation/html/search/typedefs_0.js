var searchData=
[
  ['piececolor_43',['PieceColor',['../classPiece.html#a29912828a54f09def7285afcab17a24f',1,'Piece']]],
  ['piecefigure_44',['PieceFigure',['../classPiece.html#a68f6a601dcf1081562f86da4d4ed79a9',1,'Piece']]]
];
