var searchData=
[
  ['solutioncheck_45',['SolutionCheck',['../classChess.html#ae581b9b1fc3ef23fb691ead502615cc3',1,'Chess']]]
];
