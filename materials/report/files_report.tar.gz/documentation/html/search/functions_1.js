var searchData=
[
  ['findwhiteking_27',['FindWhiteKing',['../classChess.html#acabc3d3efe6bec7e678c642997764af9',1,'Chess']]],
  ['frominttopiececolor_28',['FromIntToPieceColor',['../classPiece.html#a40a5094e87f5c7541ed81d9578625419',1,'Piece']]],
  ['frominttopiecefigure_29',['FromIntToPieceFigure',['../classPiece.html#a1d48335742dd8467beb18a23c1142056',1,'Piece']]]
];
