var searchData=
[
  ['isunderattack_9',['IsUnderAttack',['../classChess.html#a683f40d7002b836a868b3cc8f71156a0',1,'Chess']]]
];
