var searchData=
[
  ['_7echess_22',['~Chess',['../classChess.html#af4a930d9536191d6d6f1936b7d2c78ae',1,'Chess']]],
  ['_7epiece_23',['~Piece',['../classPiece.html#a51ff123520b2fcc9882d91cfeff9edab',1,'Piece']]]
];
