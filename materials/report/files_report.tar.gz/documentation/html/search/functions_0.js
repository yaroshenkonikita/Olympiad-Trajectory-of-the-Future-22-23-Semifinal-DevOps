var searchData=
[
  ['chess_26',['Chess',['../classChess.html#a8b493f742d0ceced6f853fa30d3c05a8',1,'Chess::Chess()'],['../classChess.html#a4bf360ba3f88e7d04e0999cb7bff9316',1,'Chess::Chess(Piece &amp;piece_for_fill)']]]
];
