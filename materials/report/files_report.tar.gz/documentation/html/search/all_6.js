var searchData=
[
  ['solution_18',['Solution',['../classChess.html#a00fd7c238ffa1586107ca4e3405fb97d',1,'Chess']]],
  ['solutioncheck_19',['SolutionCheck',['../classChess.html#ae581b9b1fc3ef23fb691ead502615cc3',1,'Chess']]]
];
