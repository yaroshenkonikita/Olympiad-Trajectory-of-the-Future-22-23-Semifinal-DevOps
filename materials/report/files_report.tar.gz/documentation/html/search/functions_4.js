var searchData=
[
  ['operator_21_3d_33',['operator!=',['../classPiece.html#ab246d2381c6916f9f0da3773404b49fb',1,'Piece']]],
  ['operator_2a_34',['operator*',['../classPiece.html#a5577083a840b414d21ba7c2ecd75e13e',1,'Piece']]],
  ['operator_3d_35',['operator=',['../classPiece.html#a2e4a1f810b118ece82eb7ff2a428c5ea',1,'Piece::operator=(Piece &amp;other) noexcept'],['../classPiece.html#af022dc7028757735e3343b33e83450ef',1,'Piece::operator=(Piece &amp;&amp;other) noexcept']]],
  ['operator_3d_3d_36',['operator==',['../classPiece.html#a5f5c044ff03b1096f820efff0b60720c',1,'Piece']]]
];
