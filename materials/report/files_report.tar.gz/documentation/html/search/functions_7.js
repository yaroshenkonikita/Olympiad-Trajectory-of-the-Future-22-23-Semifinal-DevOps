var searchData=
[
  ['underattackondiagonally_39',['UnderAttackOnDiagonally',['../classChess.html#abce6ef609bc10132ff35864c4d6d8f9d',1,'Chess']]],
  ['underattackonhorizontally_40',['UnderAttackOnHorizontally',['../classChess.html#a18aad266646b04b6bbf42927c32171db',1,'Chess']]]
];
