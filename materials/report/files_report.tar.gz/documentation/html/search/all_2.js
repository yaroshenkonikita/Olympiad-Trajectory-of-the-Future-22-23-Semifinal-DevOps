var searchData=
[
  ['getcolor_7',['GetColor',['../classPiece.html#a4052b1a856660aaa89ce0d27aa7d9833',1,'Piece']]],
  ['getpiece_8',['GetPiece',['../classChess.html#ab5a9a6ce3bdb4bcfd8db19bfdbdad73c',1,'Chess::GetPiece()'],['../classPiece.html#a93f8caca973c8909e10ee422e63b3863',1,'Piece::GetPiece()']]]
];
