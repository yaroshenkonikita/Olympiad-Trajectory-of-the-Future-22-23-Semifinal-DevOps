var searchData=
[
  ['piece_37',['Piece',['../classPiece.html#ae3a5cfda8e4c7520404f2f4389f4f1c1',1,'Piece::Piece() noexcept=default'],['../classPiece.html#addcd1636e15f296e6f898dde044cacec',1,'Piece::Piece(PieceFigure figure, PieceColor color) noexcept']]]
];
