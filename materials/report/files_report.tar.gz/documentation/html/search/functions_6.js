var searchData=
[
  ['solution_38',['Solution',['../classChess.html#a00fd7c238ffa1586107ca4e3405fb97d',1,'Chess']]]
];
